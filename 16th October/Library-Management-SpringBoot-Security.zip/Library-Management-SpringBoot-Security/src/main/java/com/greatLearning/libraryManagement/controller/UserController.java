package com.greatLearning.libraryManagement.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.greatLearning.libraryManagement.entity.User;
import com.greatLearning.libraryManagement.event.RegistrationCompleteEvent;
import com.greatLearning.libraryManagement.service.UserService;

//USER REGISTRATION 

public class UserController {
	
	@Autowired
	UserService service;
	
	@Autowired
	ApplicationEventPublisher publisher;
	
	@PostMapping("/register")
	public String registerUser(@RequestBody User user, HttpServletRequest request) {
		User savedUser = service.addUser(user);
		publisher.publishEvent(new RegistrationCompleteEvent(savedUser, 
				"http://" + request.getServerName()+":"
				+ request.getServerPort()+
				request.getContextPath()));
		return "success";
	}
}
