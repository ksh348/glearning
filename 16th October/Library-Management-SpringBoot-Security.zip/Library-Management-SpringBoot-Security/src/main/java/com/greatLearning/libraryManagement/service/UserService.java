package com.greatLearning.libraryManagement.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.greatLearning.libraryManagement.entity.User;
import com.greatLearning.libraryManagement.entity.VerificationToken;
import com.greatLearning.libraryManagement.repository.UserRepository;
import com.greatLearning.libraryManagement.repository.VerificationTokenRepository;

//USER REGISTRATION 

public class UserService {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	VerificationTokenRepository verificationRepository;
	
	public User addUser(User user) {
		return userRepository.save(user);
	}

	public void saveVerificationTokenForUser(String token, User user) {
		VerificationToken verificationToken = new VerificationToken(user,token);
		
		verificationRepository.save(verificationToken);
	}
}
