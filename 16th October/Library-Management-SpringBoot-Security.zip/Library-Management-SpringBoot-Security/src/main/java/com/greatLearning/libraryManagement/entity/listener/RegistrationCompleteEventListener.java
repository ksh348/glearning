package com.greatLearning.libraryManagement.entity.listener;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;

import com.greatLearning.libraryManagement.entity.User;
import com.greatLearning.libraryManagement.event.RegistrationCompleteEvent;
import com.greatLearning.libraryManagement.service.UserService;

//USER REGISTRATION 

public class RegistrationCompleteEventListener implements 
	ApplicationListener<RegistrationCompleteEvent>
{

	@Autowired
	private UserService service;
	
	@Override
	public void onApplicationEvent(RegistrationCompleteEvent event) {
		User user = event.getUser();
		
		String token = UUID.randomUUID().toString();
		
		service.saveVerificationTokenForUser(token, user);
		
		String url = event.getUrl() + "Verrify" + token;
		
		//send verification email method
		System.out.println("Click the link to verify :  " + url);
	}

}
