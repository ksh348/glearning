package com.greatLearning.libraryManagement.entity;


import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;
import lombok.NoArgsConstructor;

//USER REGISTRATION 

@Entity
@Data
@NoArgsConstructor
public class  VerificationToken{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private Long id;
	
	private String token;
	
	private Date expiry;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id", nullable = false, 
			foreignKey = @ForeignKey(name = "FK_USER_VERIFICATION"))
	private User user;
	
	public VerificationToken(User user, String token) {
		this.user = user;
		this.token = token;
		this.expiry = expiryDate(10);
	}
	
	public VerificationToken(String token) {
		this.token = token;
		this.expiry = expiryDate(10);
	}
	private Date expiryDate(int duration) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(new Date().getTime());
		cal.add(Calendar.MINUTE, duration);
		return new Date(cal.getTime().getDate());
	}
}
