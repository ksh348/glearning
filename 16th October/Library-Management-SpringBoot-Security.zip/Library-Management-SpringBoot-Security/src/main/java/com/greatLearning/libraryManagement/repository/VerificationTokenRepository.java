package com.greatLearning.libraryManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.greatLearning.libraryManagement.entity.VerificationToken;

//USER REGISTRATION 

@Repository
public interface VerificationTokenRepository extends JpaRepository<VerificationToken, Long>{

}
